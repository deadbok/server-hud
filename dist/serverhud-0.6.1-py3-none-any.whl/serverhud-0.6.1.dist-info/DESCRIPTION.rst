==========

Limited status display running on older hardware. Shows the status of the firewall 
and the web server.

Home-page: https://github.com/deadbok/server-hud
Author: Martin Bo Kristensen Grønholdt
Author-email: martin.groenholdt@gmail.com
License: GNU General Public License v2 (GPLv2)
Description-Content-Type: UNKNOWN
Description: UNKNOWN
Platform: UNKNOWN
Classifier: Development Status :: 4 - Beta
Classifier: Framework :: Flask
Classifier: Topic :: System :: Monitoring
Classifier: Topic :: System :: Networking
Classifier: License :: OSI Approved :: GNU General Public License v2 (GPLv2)
Classifier: Programming Language :: Python :: 3
Classifier: Programming Language :: Python :: 3.5
Requires-Python: >=3
