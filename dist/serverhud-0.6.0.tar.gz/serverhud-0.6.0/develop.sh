make
pip3 install --user -e .
