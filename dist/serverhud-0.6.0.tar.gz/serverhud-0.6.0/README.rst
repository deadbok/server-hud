Server HUD
==========

Limited status display running on older hardware. Shows the status of the firewall 
and the web server.
