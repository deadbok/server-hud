import React from 'react';
import PropTypes from 'prop-types';
import PanelHeader from '../header/PanelHeader';

class PanelText extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      class: 'col-' + props.size,
      maxBB: undefined
    };
    this.scale = 1;
  }

  measure(text, scale) {
    let el = document.createElement('span');

    el.style.visibility = 'hidden';
    el.style.position = 'absolute';
    /*el.style.fontSize = scale + 'vh';*/

    document
      .body
      .appendChild(el);
    el.innerHTML = text;
    let ret = el.getBoundingClientRect();
    el
      .parentNode
      .removeChild(el);
    return (ret);
  }

  componentDidMount() {
    this.setState({
      maxBB: this
        .panelBody
        .getBoundingClientRect()
    });
  }

  /**
   * Render the text component.
   *
   * @return div with component.
   * @memberof PanelText
   */
  // return <p className="high" key={i} style={this.fixWidth(line)}>{line}</p>; },
  // this)
  render() {
    //Render each line as a seperate paragraph
    let boundingBoxes = [];

    let scale = 9999;
    if (this.scale === 1) {
      if (this.state.maxBB !== undefined) {
        this
          .props
          .lines
          .forEach(line => {
            const currentBB = this.measure(line.trim(), scale)

            scale = Math.min(this.state.maxBB.width / currentBB.width, this.state.maxBB.height / currentBB.height, scale);
            boundingBoxes.push(currentBB)
          });
      }
    }
    if (scale === 9999) {
      scale = 1;
    }
    return <div className={this.state.class}>
      <PanelHeader title={this.props.title}/>
      <div
        className="panel-body"
        ref={(element) => {
        this.panelBody = element;
      }}>
        {this
          .props
          .lines
          .map(function (line, i,) {
            let width = 1;
            let originX = 1;
            let originY = 1;

            if (this.state.maxBB !== undefined) {
              originX = ((this.state.maxBB.width - boundingBoxes[i].width) / 2) * scale;
              originY = (boundingBoxes[i].height * scale * i);
            }

            console.log(line.trim());
            console.log(originX);
            console.log(originY);
            console.log(scale);

            return <span
              className="high"
              key={i}
              style={{
              transform: "matrix(" + scale + ", 0, 0, " + scale + ", " + originX + ", " + originY + ")"
            }}>{line.trim()}</span>;
          }, this)}
      </div>
    </div>;
  }
}

PanelText.defaultProps = {
  size: 1,
  lines: [''],
  style: {}
}

PanelText.propTypes = {
  /** Grid size of compoment */
  size: PropTypes.number,
  /** Text lines */
  lines: PropTypes.arrayOf(PropTypes.string)
}

export default PanelText;