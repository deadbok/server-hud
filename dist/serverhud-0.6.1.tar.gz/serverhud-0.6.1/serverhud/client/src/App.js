import React, {Component} from 'react';
//Headers
import PageHeader from './components/header/PageHeader';
import PanelHeader from './components/header/PanelHeader';
//Content
import PanelConnected from './components/content/PanelConnected';
import PanelSpeed from './components/content/PanelSpeed';
import PanelHost from './components/content/PanelHost';
import PanelUptime from './components/content/PanelUptime'
import PanelAccesses from './components/content/PanelAccesses'
import './App.css';

class App extends Component {
  render() {
    return (
      <div>
        <div className="half_screen">
          <PageHeader className="panel-heading" title="serverhud"/>
          <PanelHeader title="Web server stats"/>
          <div className="panel-row">
            <PanelConnected
              title="Connected"
              url="ws://192.168.3.3:5000/ws/connections"
              size={2}
              maxScale={9}/>
            <PanelHost
              url="ws://192.168.3.3:5000/ws/remote_host"
              title="Latest remote address"
              size={6}/>
            <PanelUptime url="ws://192.168.3.3:5000/ws/uptime" title="Uptime" size={2}/>
            <PanelAccesses
              url="ws://192.168.3.3:5000/ws/accesses"
              title="Accesses"
              size={2}/>
          </div>
        </div>
        <div className="half_screen">
          <PanelHeader title="Firewall stats"/>
          <div className="panel-row">
            <PanelConnected
              title="Connected"
              url="ws://malcolm:5000/ws/connections"
              size={2}
              maxScale={9}/>
            <PanelSpeed title="Receive speed" direction="receive" size={5} maxScale={9}/>
            <PanelSpeed title="Send speed" direction="send" size={5} maxScale={9}/>
          </div>
        </div>
        <div className="footer">
          <div className="text-center">
            server-hud Copyright &copy; 20015-2018 Martin Bo Kristensen Gr&oslash;nholdt.
          </div>
        </div>
      </div>
    );
  }
}

export default App;
