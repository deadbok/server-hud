# Full system test

Test that brings up a full virtual environment to test the application

## Dependencies

 * Vagrant:
    * vagrant-hostmanager
